
    cat_baixo = [carregaImagem("Recursos/imagens/cat/cat_baixo1.png",(32 ,32)),
                carregaImagem("Recursos/imagens/cat/cat_baixo2.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_baixo3.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_baixo4.png",(32,32))]
    
    cat_cima = [carregaImagem("Recursos/imagens/cat/cat_cima1.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_cima2.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_cima3.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_cima4.png",(32,32))]
     
    cat_direita = [carregaImagem("Recursos/imagens/cat/cat_direita1.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_direita2.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_direita3.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_direita4.png",(32,32))]
    
    cat_esquerda = [carregaImagem("Recursos/imagens/cat/cat_esquerda1.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_esquerda2.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_esquerda3.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_esquerda4.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_esquerda4.png",(32,32))]