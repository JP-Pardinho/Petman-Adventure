######################################################
# Introdução a Programação (2023/2)
# EP2 - PacMan
# Integrante 1:
# Integrante 2:
# Integrante 3:
# Integrante 4: 
######################################################


#ATENÇÃO: você não pode importar o módulo PyGame neste arquivo. 
#Consequentemente, você não pode usar o métodos do módulo.
#Você pode, se precisar, importar o módulo math e/ou random.
from BaseParaJogo import *
import random

CORFUNDOJANELA = (120, 120, 128)
LARGURAJANELA = 800
ALTURAJANELA = 672
ICONE = "Recursos/imagens/icone.png"
PARADO = 0
CIMA = 1
BAIXO = 2
ESQUERDA = 3
DIREITA = 4

MAPA = [
[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],   
[1,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,1],
[1,2,1,2,1,2,1,1,1,2,1,1,1,1,1,2,1,1,1,2,1,2,1,2,1],
[1,2,2,2,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,2,2,2,1],
[1,1,1,2,1,1,1,2,2,2,1,2,2,2,1,2,2,2,1,1,1,2,1,1,1],
[1,2,2,2,2,2,1,2,1,1,1,1,2,1,1,1,1,2,1,2,2,2,2,2,1],
[1,2,1,1,1,2,1,2,2,2,2,2,2,2,2,2,2,2,1,2,1,1,1,2,1],
[1,2,2,2,2,2,1,1,2,1,1,1,1,1,1,1,2,1,1,2,2,2,2,2,1],
[1,2,1,2,1,2,2,1,2,2,2,2,1,2,2,2,2,1,2,2,1,2,1,2,1],
[1,2,1,2,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,2,1,2,1],
[1,2,1,2,2,2,2,1,2,2,2,2,1,2,2,2,2,1,2,2,2,2,1,2,1],
[1,2,2,2,1,2,1,1,2,1,1,1,1,1,1,1,2,1,1,2,1,2,2,2,1],
[1,2,1,2,1,2,2,2,2,2,2,2,3,2,2,2,2,2,2,2,1,2,1,2,1],
[1,1,1,2,1,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,1,2,1,1,1],
[1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
[1,2,1,2,1,2,1,1,1,1,2,1,1,1,2,1,1,1,1,2,1,2,1,2,1],
[1,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,1],
[1,2,1,2,1,2,1,1,1,2,1,1,1,1,1,2,1,1,1,2,1,2,1,2,1],
[1,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,1],
[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]


def desenhaMapa(parede, fundo, pilula):
    for l in range(len(MAPA)):
        for c in range(len(MAPA[l])):
            if MAPA[l][c]   == 0:
                desenhaImagem(fundo, c*32, l*32)
            elif MAPA[l][c] == 1:
                desenhaImagem(fundo, c*32, l*32)
                desenhaImagem(parede, c*32, l*32)
            elif MAPA[l][c] == 2:
                desenhaImagem(fundo, c*32, l*32)
                desenhaImagem(pilula, c*32, l*32)
            elif MAPA[l][c] == 3:
                desenhaImagem(fundo, c*32, l*32)
            elif MAPA[l][c] == 4:
                desenhaImagem(fundo, c*32, l*32)



def movimentacao(xGato, yGato, intencao):
    
    """
    Verifica se a direção não está indo para uma parede,
    se sim, retorna True, caso contrario False

    Parâmetros:
        xGato:      Posição em relação ao eixo X
        yGato:      Posição em relação ao eixo Y
        intencao:   Qual tecla foi precionada

    Retorno:
        Valor booleano (True/False)
    """
    tamanho_gato = 32

    if intencao == CIMA:
        if MAPA[(yGato - 1)//32][(xGato) //32] != 1 and MAPA[(yGato - 1)//32][(xGato + tamanho_gato - 1)//32] != 1:
            return True
    elif intencao == BAIXO:
        if MAPA[(yGato + tamanho_gato) //32][(xGato) //32] != 1 and MAPA[(yGato + tamanho_gato) //32][(xGato + tamanho_gato - 1) //32] != 1:
            return True
    elif intencao == ESQUERDA:
        if MAPA[(yGato) //32][(xGato - 1) //32] != 1 and MAPA[(yGato + tamanho_gato - 1) //32][(xGato - 1) //32] != 1:
            return True
    elif intencao == DIREITA:
        if MAPA[(yGato) //32][(xGato + tamanho_gato) //32] != 1 and MAPA[(yGato + tamanho_gato - 1) //32][(xGato + tamanho_gato) //32] != 1:
            return True
    return False

    
def fantasma_parede(xFant, yFant, dire):
    tamanho_fant = 31
    if dire == CIMA and MAPA[(yFant - 1) //32][(xFant) //32] != 1 and MAPA[(yFant - 1) //32][(xFant + tamanho_fant) //32] != 1:
        return True
    elif dire == BAIXO and MAPA[(yFant + tamanho_fant + 1) //32][(xFant) //32] != 1 and MAPA[(yFant + tamanho_fant + 1) //32][(xFant + tamanho_fant) //32] != 1:
        return True
    elif dire == ESQUERDA and MAPA[(yFant) //32][(xFant - 1) //32] != 1 and MAPA[(yFant + tamanho_fant) //32][(xFant - 1) //32] != 1:
        return True
    elif dire == DIREITA and MAPA[(yFant) //32][(xFant + tamanho_fant + 1) //32] != 1 and MAPA[(yFant + tamanho_fant) //32][(xFant + tamanho_fant + 1) //32] != 1:
        return True
    return False
    



def main():
    """
    Função reponsavel por atualizar imagens, 
    """
    criaJanela(LARGURAJANELA, ALTURAJANELA, "Pac-Man", CORFUNDOJANELA,ICONE)


    parede = carregaImagem("Recursos/imagens/parede/parede_teste.png", (32, 32))
    fundo  = carregaImagem("Recursos/imagens/parede/fundo_grama.png", (32,32))
    
    pilula = carregaImagem("Recursos/imagens/pilula/peixe_v01.png", (32, 32))

    cat_baixo = [carregaImagem("Recursos/imagens/cat/cat_baixo1.png",(32 ,32)),
                carregaImagem("Recursos/imagens/cat/cat_baixo2.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_baixo3.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_baixo4.png",(32,32))]
    
    cat_cima = [carregaImagem("Recursos/imagens/cat/cat_cima1.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_cima2.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_cima3.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_cima4.png",(32,32))]
     
    cat_direita = [carregaImagem("Recursos/imagens/cat/cat_direita1.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_direita2.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_direita3.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_direita4.png",(32,32))]
    
    cat_esquerda = [carregaImagem("Recursos/imagens/cat/cat_esquerda1.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_esquerda2.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_esquerda3.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_esquerda4.png",(32,32)),
                carregaImagem("Recursos/imagens/cat/cat_esquerda4.png",(32,32))]
    
    caramelo_baixo      = [carregaImagem("Recursos/imagens/caramelo/caramelo_baixo1.png",(32,32)),
                        carregaImagem("Recursos/imagens/caramelo/caramelo_baixo2.png",(32,32)),
                        carregaImagem("Recursos/imagens/caramelo/caramelo_baixo3.png",(32,32))]

    caramelo_cima       =  [carregaImagem("Recursos/imagens/caramelo/caramelo_cima1.png",(32,32)),
                        carregaImagem("Recursos/imagens/caramelo/caramelo_cima2.png",(32,32)),
                        carregaImagem("Recursos/imagens/caramelo/caramelo_cima3.png",(32,32))]

    caramelo_direita    = [carregaImagem("Recursos/imagens/caramelo/caramelo_direita1.png",(32,32)),
                        carregaImagem("Recursos/imagens/caramelo/caramelo_direita2.png",(32,32)),
                        carregaImagem("Recursos/imagens/caramelo/caramelo_direita3.png",(32,32))]

    caramelo_esquerda   = [carregaImagem("Recursos/imagens/caramelo/caramelo_esquerda1.png",(32,32)),
                        carregaImagem("Recursos/imagens/caramelo/caramelo_esquerda2.png",(32,32)),
                        carregaImagem("Recursos/imagens/caramelo/caramelo_esquerda3.png",(32,32))]


    
    # Variaveis fantasma 1

    imagemFantasma1 = caramelo_baixo
    xFantasma1 = 32
    yFantasma1 = 32
    frameFantasma1 = 0
    intencao_f1 = DIREITA
    direcao_f1 = DIREITA

    # Variaveis Gato
    imagemJogador = cat_baixo
    frameJogador = 0 
    xJogador = 384
    yJogador = 384
    velocidadeAnimacaoJogador = 0.1
    intencao = PARADO
    direcao = PARADO
    movimento = False
    pontos = 0
    tamanho_gato = 32
    vitoria = 2560
    vida = 3


    # if pontos < vitoria and vida > 0:
    while True:

        while pontos < 2560 and vida > 0:   
            
            if teclaPressionada(K_ESCAPE):
                break
            limpaTela()
            #Verifica se uma das teclas foi precionada
            #Se sim, atualiza a posição do

                
            if teclaPressionada(K_UP):
                intencao = CIMA

            elif teclaPressionada(K_DOWN):
                intencao = BAIXO

            elif teclaPressionada(K_LEFT):
                intencao = ESQUERDA

            elif teclaPressionada(K_RIGHT):
                intencao = DIREITA

            
            if intencao == CIMA and movimentacao(xJogador, yJogador, intencao):
                imagemJogador = cat_cima
                direcao = intencao

            elif intencao == BAIXO and movimentacao(xJogador, yJogador, intencao):
                imagemJogador = cat_baixo
                direcao = intencao
                
            elif intencao == ESQUERDA and movimentacao(xJogador, yJogador, intencao):
                imagemJogador = cat_esquerda
                direcao = intencao

            elif intencao == DIREITA and movimentacao(xJogador, yJogador, intencao):
                imagemJogador = cat_direita
                direcao = intencao
                
                

            if direcao == CIMA and movimentacao(xJogador, yJogador, direcao):
                yJogador -= 2
                if MAPA[yJogador // 32][xJogador //32] == 2:
                    MAPA[yJogador // 32][xJogador //32] = 0
                    pontos += 10
            
            elif direcao == BAIXO and movimentacao(xJogador, yJogador, direcao):
                yJogador += 2
                if MAPA[yJogador // 32][xJogador //32] == 2:
                    MAPA[yJogador // 32][xJogador //32] = 0
                    pontos += 10                    
            
            elif direcao == ESQUERDA and movimentacao(xJogador, yJogador, direcao):
                xJogador -= 2
                if MAPA[yJogador // 32][xJogador //32] == 2:
                    MAPA[yJogador // 32][xJogador //32] = 0
                    pontos += 10                    
            
            elif direcao == DIREITA and movimentacao(xJogador, yJogador, direcao):
                xJogador += 2
                if MAPA[yJogador // 32][xJogador //32] == 2:
                    MAPA[yJogador // 32][xJogador //32] = 0
                    pontos += 10                    
            else:
                direcao = PARADO


            #Sorteia a direção do fantasma 1
            
            intencao_f1 = random.randint(CIMA,DIREITA)

            if intencao_f1 == CIMA and fantasma_parede(xFantasma1, yFantasma1, direcao_f1):
                imagemFantasma1 = caramelo_cima
                intencao_f1 = direcao_f1
            elif intencao_f1 == BAIXO and fantasma_parede(xFantasma1, yFantasma1, direcao_f1):
                imagemFantasma1 = caramelo_baixo
                intencao_f1 = direcao_f1
            elif intencao_f1 == ESQUERDA and fantasma_parede(xFantasma1, yFantasma1, direcao_f1):
                imagemFantasma1 = caramelo_esquerda
                intencao_f1 = direcao_f1
            elif intencao_f1 == DIREITA and fantasma_parede(xFantasma1, yFantasma1, direcao_f1):
                imagemFantasma1 = caramelo_direita
                intencao_f1 = direcao_f1
            else:
                intencao_f1 = random.randint(CIMA,DIREITA)
                direcao_f1 = intencao_f1

            
            
            if direcao_f1 == CIMA and fantasma_parede(xFantasma1, yFantasma1, direcao_f1):
                yFantasma1 -= 2
                imagemFantasma1 = caramelo_cima
            elif direcao_f1 == BAIXO and fantasma_parede(xFantasma1, yFantasma1, direcao_f1):
                yFantasma1 += 2
                imagemFantasma1 = caramelo_baixo
            elif direcao_f1 == ESQUERDA and fantasma_parede(xFantasma1, yFantasma1, direcao_f1):
                xFantasma1 -= 2
                imagemFantasma1 = caramelo_esquerda
            elif direcao_f1 == DIREITA and fantasma_parede(xFantasma1, yFantasma1, direcao_f1):
                xFantasma1 += 2
                imagemFantasma1 = caramelo_direita
            
            if yFantasma1 == yJogador and xFantasma1 == xJogador:
                vida -= 1 
                xJogador = 384
                yJogador = 384



            #Desenha mapa
            desenhaMapa(parede,fundo,pilula)
            
            #Desenha o jogador
            if direcao != PARADO:
                frameJogador += velocidadeAnimacaoJogador
                if frameJogador >= 4:
                    frameJogador = 0
                desenhaImagem(imagemJogador[int(frameJogador)], xJogador, yJogador)
            else:
                desenhaImagem(imagemJogador[0], xJogador, yJogador)

            # # Desenha o fantasma 1
            if direcao_f1 != 0:
                frameFantasma1 += velocidadeAnimacaoJogador
                if frameFantasma1 >= 3:
                    frameFantasma1 = 0
                desenhaImagem(imagemFantasma1[int(frameFantasma1)], xFantasma1, yFantasma1)
            else:
                desenhaImagem(imagemFantasma1[0], xFantasma1, yFantasma1)

            desenhaTexto(f"Pontos: {pontos}", 432, 656, 20, (255, 247, 0), "Recursos/fontes/DePixelHalbfett.ttf")



            #Atualiza os objetos na janela
            atualizaTelaJogo()

        
        while pontos >= 2560 and vida > 0:
            if teclaPressionada(K_ESCAPE):
                finalizaJogo()
            limpaTela()
            desenhaTexto("Você venceu!", 416, 320, 50, (255, 247, 0), "Recursos/fontes/DePixelHalbfett.ttf")
            desenhaTexto("pressione espaço para sair", 416, 464, 20, (255, 247, 0), "Recursos/fontes/DePixelHalbfett.ttf")
            if teclaPressionada(K_SPACE):
                finalizaJogo()
            atualizaTelaJogo()
        

        while vida == 0:
            if teclaPressionada(K_ESCAPE):
                finalizaJogo()
            limpaTela()
            desenhaTexto("Voce perdeu!!!!!", 416, 320, 50, (255, 247, 0), "Recursos/fontes/DePixelHalbfett.ttf")
            desenhaTexto("pressione espaço para reiniciar o jogo", 416, 464, 20, (255, 247, 0), "Recursos/fontes/DePixelHalbfett.ttf")
            if teclaPressionada(K_SPACE):
                vida = 3
                pontos = 0
                xJogador = 384
                yJogador = 384
                intencao = PARADO
                direcao = PARADO
                for l in range(len(MAPA)):
                    for c in range(len(MAPA[l])):
                        if MAPA[l][c]   == 0:
                            MAPA[l][c] = 2
                

            atualizaTelaJogo()
            
    

        

main()